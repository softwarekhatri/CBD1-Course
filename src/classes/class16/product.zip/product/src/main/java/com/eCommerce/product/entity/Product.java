package com.eCommerce.product.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

/**
 * @author Ankit Khatri
 */

@Data
@Document(collection = "products")
public class Product {

    @Id
    private String id;

    private String name;

    private List<String> images;

//    @Enumerated(EnumType.STRING)
    private String category;

    private Double ratings;

    private Double price;

    private Integer stockQuantity;

    private Date createdAt;
    private Date updatedAt;
}
