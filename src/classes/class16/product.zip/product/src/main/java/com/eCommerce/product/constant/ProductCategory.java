package com.eCommerce.product.constant;

/**
 * @author Ankit Khatri
 */
public enum ProductCategory {
    MENS_WEAR, WOMEN_WEAR, KIDS_WEAR
}
