package com.eCommerce.product.service;

import com.eCommerce.product.constant.ProductCategory;
import com.eCommerce.product.constant.ProductFieldSort;
import com.eCommerce.product.converter.ProductConverter;
import com.eCommerce.product.dao.ProductRepository;
import com.eCommerce.product.dto.ProductDto;
import com.eCommerce.product.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Ankit Khatri
 */

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired private ProductRepository productRepository;

    @Override
    public ProductDto createNewProduct(ProductDto productDto) {
        Product product = ProductConverter.convertToEntity(productDto);
        Product savedInDB = productRepository.save(product);
        return ProductConverter.convertToDto(savedInDB);
    }

    @Override
    public List<ProductDto> getAllProducts() {
        List<ProductDto> productDtoList = new ArrayList<>();
        List<Product> products = productRepository.findAll();
        if(!CollectionUtils.isEmpty(products)) {
            for (Product product : products) {
                ProductDto productDto = ProductConverter.convertToDto(product);
                productDtoList.add(productDto);
            }
        }
        return productDtoList;
    }

    @Override
    public ProductDto getById(Integer id) {
        Optional<Product> product = productRepository.findById(id);
        if(product.isPresent()){
            return ProductConverter.convertToDto(product.get());
        }
        return null;
    }

    @Override
    public void updateProduct(Integer id, ProductDto input) {
        Optional<Product> productOptional = productRepository.findById(id);
        if(productOptional.isPresent()){
            Product productInDB = productOptional.get();
            if(input.getName() != null){
                productInDB.setName(input.getName());
            }
            if(input.getCategory() != null){
                productInDB.setCategory(input.getCategory());
            }
            if(input.getRatings() != null){
                productInDB.setRatings(input.getRatings());
            }
            if(input.getImages() != null){
                productInDB.setImages(input.getImages());
            }
            if(input.getPrice() != null){
                productInDB.setPrice(input.getPrice());
            }
            if(input.getStockQuantity() != null){
                productInDB.setStockQuantity(input.getStockQuantity());
            }
            productRepository.save(productInDB);
        }
    }

    @Override
    public void deleteProduct(Integer id) {
        productRepository.deleteById(id);
    }

    @Override
    public List<ProductDto> filterProducts(String query) {
        List<ProductDto> response = new ArrayList<>();
        List<Product> filteredProducts = productRepository.findByNameContainingOrCategoryContaining(query, query);
        if(!CollectionUtils.isEmpty(filteredProducts)) {
            for (Product product : filteredProducts) {
                ProductDto productDto = ProductConverter.convertToDto(product);
                response.add(productDto);
            }
        }
        return response;
    }

    @Override
    public List<ProductDto> sortProduct(ProductFieldSort field, String sortOrder) {
        List<ProductDto> response = new ArrayList<>();
        List<Product> productList = productRepository.findAllByOrderByNameAsc();
        if(!CollectionUtils.isEmpty(productList)){
            for(Product product: productList){
                response.add(ProductConverter.convertToDto(product));
            }
        }
        return response;
    }
}
