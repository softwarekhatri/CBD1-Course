package com.eCommerce.product.converter;

import com.eCommerce.product.dto.ProductDto;
import com.eCommerce.product.entity.Product;

/**
 * @author Ankit Khatri
 */
public class ProductConverter {


    public static ProductDto convertToDto(Product product){
        ProductDto productDto = new ProductDto();
        productDto.setId(product.getId());
        productDto.setCategory(product.getCategory());
        productDto.setName(product.getName());
        productDto.setPrice(product.getPrice());
        productDto.setRatings(product.getRatings());
        productDto.setImages(product.getImages());
        productDto.setStockQuantity(product.getStockQuantity());
        return productDto;
    }

    public static Product convertToEntity(ProductDto productDto){
        Product product = new Product();
        product.setCategory(productDto.getCategory());
        product.setName(productDto.getName());
        product.setPrice(productDto.getPrice());
        product.setRatings(productDto.getRatings());
        product.setImages(productDto.getImages());
        product.setStockQuantity(productDto.getStockQuantity());
        return product;
    }

}
