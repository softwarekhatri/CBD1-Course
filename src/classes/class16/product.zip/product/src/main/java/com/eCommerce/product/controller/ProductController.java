package com.eCommerce.product.controller;

import com.eCommerce.product.constant.ProductFieldSort;
import com.eCommerce.product.dto.ProductDto;
import com.eCommerce.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired private ProductService productService;

    @PostMapping("/create")
    public ResponseEntity<?> createNewProduct(@RequestBody ProductDto productDto){
        ProductDto response = productService.createNewProduct(productDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/getAll")
    public ResponseEntity<?> getAllProducts(){
        List<ProductDto> productDtoList = productService.getAllProducts();
        return ResponseEntity.status(HttpStatus.OK).body(productDtoList);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<?> getProductById(@PathVariable("id") Integer id){
        ProductDto productDto = productService.getById(id);
        return ResponseEntity.status(HttpStatus.OK).body(productDto);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateProductById(@PathVariable Integer id, @RequestBody ProductDto productDto){
        productService.updateProduct(id, productDto);
        return ResponseEntity.status(HttpStatus.OK).body("Updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteProductById(@PathVariable Integer id){
        productService.deleteProduct(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Deleted");
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterProducts(@RequestParam("query") String query){
        List<ProductDto> response = productService.filterProducts(query);
       return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/sort/{field}/{sortOrder}")
    public ResponseEntity<?> sortProduct(@PathVariable("field") ProductFieldSort field, @PathVariable("sortOrder") String sortOrder){
        List<ProductDto> response = productService.sortProduct(field, sortOrder);
        return ResponseEntity.ok(response);
    }
}
