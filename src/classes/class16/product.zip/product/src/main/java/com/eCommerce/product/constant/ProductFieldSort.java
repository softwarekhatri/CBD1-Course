package com.eCommerce.product.constant;

/**
 * @author Ankit Khatri
 */
public enum ProductFieldSort {

    RATINGS, PRICE, NAME, CREATED, UPDATED
}
