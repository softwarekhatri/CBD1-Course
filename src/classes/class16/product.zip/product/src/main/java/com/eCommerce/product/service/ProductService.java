package com.eCommerce.product.service;

import com.eCommerce.product.constant.ProductFieldSort;
import com.eCommerce.product.dto.ProductDto;
import com.eCommerce.product.entity.Product;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface ProductService {

    ProductDto createNewProduct(ProductDto productDto);

    List<ProductDto> getAllProducts();

    ProductDto getById(Integer id);

    void updateProduct(Integer id, ProductDto productDto);

    void deleteProduct(Integer id);

    List<ProductDto> filterProducts(String query);

    List<ProductDto> sortProduct(ProductFieldSort field, String sortOrder);
}
