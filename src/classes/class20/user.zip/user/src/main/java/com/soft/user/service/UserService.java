package com.soft.user.service;

import com.soft.user.dto.UserDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface UserService {

    UserDto registerUser(UserDto userDto);
    List<UserDto> getAllUsers();

    UserDto getUserById(Integer userId);
//    List<UserOrder> getAllOrders(String userId);
}
