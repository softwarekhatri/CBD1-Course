package com.soft.product.repo;

import com.soft.product.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Ankit Khatri
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
