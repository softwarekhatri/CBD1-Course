package com.soft.product.service;

import com.soft.product.dto.ProductDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface ProductService {

    ProductDto createNewProduct(ProductDto productDto);
    List<ProductDto> getAllProducts();

    List<ProductDto> getAllProductsById(List<Integer> productIds);
}
