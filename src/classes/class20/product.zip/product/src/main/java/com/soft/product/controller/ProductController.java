package com.soft.product.controller;

import com.soft.product.dto.ProductDto;
import com.soft.product.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Ankit Khatri
 */
@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/add-product")
    public ResponseEntity<?> addNewProduct(@Valid @RequestBody ProductDto productDto, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            throw new RuntimeException(bindingResult.getAllErrors().toString());
        }
        return ResponseEntity.ok(productService.createNewProduct(productDto));
    }

    @GetMapping("/get-products")
    public ResponseEntity<?> getProducts(){
        return ResponseEntity.ok(productService.getAllProducts());
    }

    @PostMapping("/get-all-products")
    public ResponseEntity<?> getProducts(@RequestBody List<Integer> productIds){
        return ResponseEntity.ok(productService.getAllProductsById(productIds));
    }
}