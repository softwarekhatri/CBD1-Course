package com.soft.product.service;

import com.soft.product.converter.ProductConverter;
import com.soft.product.dto.ProductDto;
import com.soft.product.entity.Product;
import com.soft.product.repo.ProductRepository;
import com.soft.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */
@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductRepository productRepository;

    @Override
    public ProductDto createNewProduct(ProductDto productDto) {
//        validateInput(productDto);
        Product product = productRepository.save(ProductConverter.convertToDocument(productDto));
        return ProductConverter.convertToDto(product);
    }

    private void validateInput(ProductDto productDto) {
        if(productDto.getColor() == null){
            throw new RuntimeException("Color is required");
        }

    }

    @Override
    public List<ProductDto> getAllProducts() {
        return productRepository.findAll().stream().map(product -> ProductConverter.convertToDto(product)).collect(Collectors.toList());
    }

    @Override
    public List<ProductDto> getAllProductsById(List<Integer> productIds) {
        List<ProductDto> response = new ArrayList<>();
        for(Integer productId: productIds){
            Optional<Product> productOptional = productRepository.findById(productId);
            if(!productOptional.isPresent()){
                throw new RuntimeException("Product not found");
            } else{
                response.add(ProductConverter.convertToDto(productOptional.get()));
            }
        }
        return response;
    }
}