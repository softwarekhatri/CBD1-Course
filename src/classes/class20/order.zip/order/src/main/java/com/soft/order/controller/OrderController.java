package com.soft.order.controller;

import com.soft.order.dto.OrderDto;
import com.soft.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author Ankit Khatri
 */
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/place-order")
    public ResponseEntity<?> placeOrder(@RequestBody OrderDto order){
        return ResponseEntity.ok(orderService.placeOrder(order));
    }

    @GetMapping("/get-orders")
    public ResponseEntity<?> getorders(){
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/get-complete-orders")
    public ResponseEntity<?> getCompleterders(){
        return ResponseEntity.ok(orderService.getCompleteOrders());
    }
}
