package com.soft.order.dto;

import com.soft.order.dto.external.ProductDto;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Ankit Khatri
 */

@Data
public class CompleteOrderDto {

    private String orderId;
    private Date orderPlacedAt;
    private List<ProductDto> productDtos;
    private String userName;
    private Integer userId;
}
