package com.soft.order.dto.external;

import lombok.Data;

/**
 * @author Ankit Khatri
 */

@Data
public class ProductDto {

    private String name;
    private Integer id;
    private String color;
    private String price;
}
