package com.soft.order.service;

import com.soft.order.dto.CompleteOrderDto;
import com.soft.order.dto.OrderDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface OrderService {

    OrderDto placeOrder(OrderDto orderDto);

    List<OrderDto> getAllOrders();

    List<CompleteOrderDto> getCompleteOrders();
}

