package com.soft.order.converter;

import com.soft.order.dto.OrderDto;
import com.soft.order.entity.Order;

import java.util.Date;

/**
 * @author Ankit Khatri
 */
public class OrderConveter {

    public static Order convertToDocument(OrderDto orderDto){
        Order order = Order.builder()
                .paymentId(orderDto.getPaymentId())
                .userId(orderDto.getUserId())
                .productIds(orderDto.getProductIds())
                .userName(orderDto.getUserName())
                .createdAt(new Date())
                .build();
        return order;
    }

    public static OrderDto convertToDto(Order order){
        OrderDto orderDto = OrderDto.builder()
                .id(order.getId().toHexString())
                .paymentId(order.getPaymentId())
                .userId(order.getUserId())
                .productIds(order.getProductIds())
                .createdAt(order.getCreatedAt())
                .userName(order.getUserName())
                .build();
        return orderDto;
    }


}
