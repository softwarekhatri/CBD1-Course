package com.soft.order.dto.external;

import lombok.Data;

/**
 * @author Ankit Khatri
 */

@Data
public class UserDto {

    private Integer id;
    private String name;
    private String email;
    private String password;

}
