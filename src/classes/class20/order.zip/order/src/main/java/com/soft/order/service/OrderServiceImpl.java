package com.soft.order.service;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.soft.order.converter.OrderConveter;
import com.soft.order.dto.CompleteOrderDto;
import com.soft.order.dto.OrderDto;
import com.soft.order.dto.external.ProductDto;
import com.soft.order.dto.external.UserDto;
import com.soft.order.entity.Order;
import com.soft.order.repo.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */
@Service
public class OrderServiceImpl implements OrderService{
    @Autowired
    private OrderRepository orderRepository;

    @Autowired private RestTemplate restTemplate;

    @Value("${user.service.url}") private String userBaseurl;
    @Value("${product.service.url}") private String productBaseurl;

    @Override
    public OrderDto placeOrder(OrderDto orderDto) {
        validateInputsAndThrowEx(orderDto);
        Order order =  orderRepository.save(OrderConveter.convertToDocument(orderDto));
        return OrderConveter.convertToDto(order);
    }

    @Override
    public List<OrderDto> getAllOrders() {
        return orderRepository.findAll().stream().map(order -> OrderConveter.convertToDto(order)).collect(Collectors.toList());
    }

    @Override
    public List<CompleteOrderDto> getCompleteOrders() {
        List<CompleteOrderDto> completeOrderDtos = new ArrayList<>();
        List<Order> orderList = orderRepository.findAll();
        for(Order order: orderList){
            CompleteOrderDto completeOrderDto = new CompleteOrderDto();
            completeOrderDto.setOrderId(order.getId().toHexString());
            completeOrderDto.setUserName(order.getUserName());
            completeOrderDto.setUserId(order.getUserId());
            completeOrderDto.setOrderPlacedAt(order.getCreatedAt());
            completeOrderDto.setProductDtos(getProducts(order.getProductIds()));
            completeOrderDtos.add(completeOrderDto);
        }
        return completeOrderDtos;
    }

    private List<ProductDto> getProducts(List<Integer> productIds) {
        String productUrl = productBaseurl + "/product/get-all-products";
        ResponseEntity<String> productResponse = restTemplate.exchange(productUrl, HttpMethod.POST, new HttpEntity<>(productIds), String.class);
        if(!productResponse.getStatusCode().is2xxSuccessful()){
            throw new RuntimeException("Product Details not found to place order");
        }
        List<ProductDto> productDtos = convertJsonStringInListObject(productResponse.getBody(), ProductDto.class);
        return productDtos;
    }

    public static <T> List<T> convertJsonStringInListObject(String value, Class<T> clazz) {
        ObjectMapper objectMapper = new ObjectMapper();
        JavaType type = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, clazz);
        List<T> Objectlist = new ArrayList<>();
        try {
            Objectlist = objectMapper.readValue(value, type);
        } catch (Exception e) {
        }
        return Objectlist;
    }

    private void validateInputsAndThrowEx(OrderDto orderDto) {
        // 1. whether the userId exists or not --> UserService
        // 1. URL
        // 2. HttpMethod -> GET, POST, PUT, PATCH, DELETE
        // 3. body -> HttpEntity (payload + headers)
        // 4. ResponseMapping
        String url = userBaseurl + "/user/get-by-id/" + orderDto.getUserId();
        ResponseEntity<UserDto> response = restTemplate.exchange(url, HttpMethod.GET, null, UserDto.class);
        if(!response.getStatusCode().is2xxSuccessful()){
            throw new RuntimeException("User Details not found to place order");
        }
        orderDto.setUserName(response.getBody().getName());

        // 2. whether the productIds exists or not --> ProductService
        String productUrl = productBaseurl + "/product/get-all-products";
        ResponseEntity<Object> productResponse = restTemplate.exchange(productUrl, HttpMethod.POST, new HttpEntity<>(orderDto.getProductIds()), Object.class);
        if(!productResponse.getStatusCode().is2xxSuccessful()){
            throw new RuntimeException("Product Details not found to place order");
        }
    }
}

