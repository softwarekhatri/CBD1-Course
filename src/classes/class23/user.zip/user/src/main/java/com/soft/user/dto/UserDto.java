package com.soft.user.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author Ankit Khatri
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Integer id;
//    @NotEmpty(message = "Name could not be empty")
    private String name;

//    @Email(message = "Invalid Email")
    private String email;

//    @Min(value = 5, message = "Password must be at least 5 character")
    private String password;
    private Date createdAt;
    private Date updatedAt;
}

