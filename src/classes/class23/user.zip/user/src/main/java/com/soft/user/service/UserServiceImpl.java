package com.soft.user.service;

import com.soft.user.conveter.UserConverter;
import com.soft.user.dto.UserDto;
import com.soft.user.entity.User;
import com.soft.user.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDto registerUser(UserDto userDto) {
        User user = UserConverter.convertToDocument(userDto);
        User userStoredInDB = userRepository.save(user);
        return UserConverter.covertToDto(userStoredInDB);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map(user -> UserConverter.covertToDto(user)).collect(Collectors.toList());
    }

    @Override
    public UserDto getUserById(Integer userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if(!userOptional.isPresent()){
            throw new RuntimeException("User Not found");
        }
        return UserConverter.covertToDto(userOptional.get());
    }

}
