package com.soft.user.conveter;

import com.soft.user.dto.UserDto;
import com.soft.user.entity.User;

/**
 * @author Ankit Khatri
 */
public class UserConverter {

    public static User convertToDocument(UserDto userDto){
        return new User(userDto);
    }

    public static UserDto covertToDto(User user){
        UserDto userDto = UserDto.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .password(user.getPassword())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getLastUpdatedAt())
                .build();
        return userDto;
    }
}
