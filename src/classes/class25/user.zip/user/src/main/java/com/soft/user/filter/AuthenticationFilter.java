package com.soft.user.filter;

import com.soft.user.service.AuthenticationService;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * @author Ankit Khatri
 */
// POJO ==> Plain old java object

@Service
public class AuthenticationFilter extends OncePerRequestFilter {

    @Autowired private AuthenticationService authenticationService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        if(request.getHeader("Authorization") != null && request.getHeader("Authorization").startsWith("Token-ANKIT:")){
            String email = extractEmailFromToken(request.getHeader("Authorization"));
            UserDetails userDetails = authenticationService.loadUserByUsername(email);
            if(SecurityContextHolder.getContext().getAuthentication() == null){
                // set authentication
                UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            }
            // secured apis
            // validate token
            // set authentication
        }
        chain.doFilter(request, response);
    }

    // "Token-ANKIT:ankit@gmail.com"
    private String extractEmailFromToken(String authorization) {
        return authorization.split(":")[1];
    }

}
