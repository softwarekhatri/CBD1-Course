package com.soft.user.dto;

import lombok.Data;

/**
 * @author Ankit Khatri
 */

@Data
public class LoginRequest {

    private String email;
    private String password;
}
