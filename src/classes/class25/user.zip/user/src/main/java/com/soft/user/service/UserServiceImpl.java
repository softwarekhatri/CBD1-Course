package com.soft.user.service;

import com.soft.user.constants.ExceptionCode;
import com.soft.user.conveter.UserConverter;
import com.soft.user.dto.LoginRequest;
import com.soft.user.dto.LoginResponse;
import com.soft.user.dto.UserDto;
import com.soft.user.entity.User;
import com.soft.user.exception.UserException;
import com.soft.user.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDto registerUser(UserDto userDto) {
        User user = UserConverter.convertToDocument(userDto);
        User userStoredInDB = userRepository.save(user);
        return UserConverter.covertToDto(userStoredInDB);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map(user -> UserConverter.covertToDto(user)).collect(Collectors.toList());
    }

    @Override
    public UserDto getUserById(Integer userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if(!userOptional.isPresent()){
            throw new RuntimeException("User Not found");
        }
        return UserConverter.covertToDto(userOptional.get());
    }

    // 1. we need to check the username & password is correct
    // 2. we need to generate one token
    // 3. return the token
    @Override
    public LoginResponse loginUser(LoginRequest loginRequest) {
        if(loginRequest.getEmail() == null || loginRequest.getPassword() == null){
            throw new UserException(HttpStatus.BAD_REQUEST, ExceptionCode.USERNAME_PASSWORD_REQUIRES);
        }
        // false || true ==> true

        User userStoreInDB = this.userRepository.findByEmail(loginRequest.getEmail());
        if (userStoreInDB == null || !userStoreInDB.getPassword().equals(loginRequest.getPassword())){
            throw new UserException(HttpStatus.BAD_REQUEST, ExceptionCode.INVALID_CREDENTIALS);
        }
        String newToken = generateToken(loginRequest.getEmail());
        LoginResponse loginResponse = LoginResponse.builder().token(newToken).tokenType("Ankit-Token").build();
        return loginResponse;
    }

    private String generateToken(String email) {
        return "Token-ANKIT:".concat(email);
    }

}
