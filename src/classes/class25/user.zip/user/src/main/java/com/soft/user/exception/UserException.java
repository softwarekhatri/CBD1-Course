package com.soft.user.exception;

import com.soft.user.constants.ExceptionCode;
import com.soft.user.dto.ExceptionDto;
import com.soft.user.entity.User;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

/**
 * @author Ankit Khatri
 */
@Data
@NoArgsConstructor
public class UserException extends RuntimeException {

    private ExceptionDto exceptionDto; // API response body / payload
    private HttpStatus httpStatus; // API response status

    public UserException(HttpStatus httpStatus, ExceptionCode exceptionCode){
        this.exceptionDto = new ExceptionDto(exceptionCode.getCode(), exceptionCode.getMessage());
        this.httpStatus = httpStatus;
    }
}
