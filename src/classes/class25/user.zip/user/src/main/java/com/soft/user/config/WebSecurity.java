package com.soft.user.config;

import com.soft.user.filter.AuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutFilter;

/**
 * @author Ankit Khatri
 */
// Enable main swtich to taking responsbility for enabling custom spring security configuration
@Configuration
@EnableWebSecurity
public class WebSecurity {

    @Autowired private AuthenticationFilter authenticationFilter;

    // 1. Disable csrf token
    // 2. switch to stateless session management mechanism
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
                .authorizeHttpRequests()
                    .requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/user/register", "/user/login").permitAll()
                    .anyRequest().authenticated()
                .and()
                    .addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

}
