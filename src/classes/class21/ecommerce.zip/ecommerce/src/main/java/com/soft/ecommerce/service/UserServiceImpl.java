package com.soft.ecommerce.service;

import com.soft.ecommerce.converter.UserConverter;
import com.soft.ecommerce.dto.ProductDto;
import com.soft.ecommerce.dto.UserDto;
import com.soft.ecommerce.dto.UserOrder;
import com.soft.ecommerce.entity.Order;
import com.soft.ecommerce.entity.Product;
import com.soft.ecommerce.entity.User;
import com.soft.ecommerce.repo.OrderRepository;
import com.soft.ecommerce.repo.ProductRepository;
import com.soft.ecommerce.repo.UserRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
public class UserServiceImpl implements UserService{

    @Autowired private UserRepository userRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private ProductRepository productRepository;

    @Override
    public UserDto registerUser(UserDto userDto) {
        User user = UserConverter.convertToDocument(userDto);
        User userStoredInDB = userRepository.save(user);
        return UserConverter.covertToDto(userStoredInDB);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map(user -> UserConverter.covertToDto(user)).collect(Collectors.toList());
    }

    @Override
    public List<UserOrder> getAllOrders(String userId) {
        List<UserOrder> userOrders = new ArrayList<>();
        // 1. fetch all the order of user
        List<Order> allOrders = orderRepository.findByUserId(userId);
        for(Order order: allOrders){
            Optional<User> user = userRepository.findById(new ObjectId(order.getUserId()));
            UserOrder userOrder = new UserOrder();
            if(user.isPresent()){
                userOrder.setUserName(user.get().getName());
            }
            userOrder.setOrderPlacedAt(order.getCreatedAt());
            userOrder.setUserId(userId);
            List<Product> products = new ArrayList<>();
            for(String productId: order.getProductIds()){
                Optional<Product> product = productRepository.findById(new ObjectId(productId));
                if(product.isPresent()){
                    products.add(product.get());
                }
            }
            userOrder.setOrderId(order.getId().toHexString());
            userOrder.setProducts(products);
            userOrders.add(userOrder);
        }
        return userOrders;
    }


}
