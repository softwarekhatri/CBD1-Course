package com.soft.ecommerce.exception;

import com.soft.ecommerce.constant.ExceptionCode;
import com.soft.ecommerce.dto.ExceptionDto;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

/**
 * @author Ankit Khatri
 */
@Data
@NoArgsConstructor
public class InputValidationException extends RuntimeException {
    private HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
    private ExceptionDto exceptionDto;


    public InputValidationException(ExceptionCode exceptionCode){
        this.exceptionDto = new ExceptionDto(exceptionCode.getCode(), exceptionCode.getErrorMessage());
    }

}
