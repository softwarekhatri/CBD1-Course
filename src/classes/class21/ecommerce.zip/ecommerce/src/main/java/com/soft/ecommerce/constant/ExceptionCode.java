package com.soft.ecommerce.constant;

import lombok.Getter;
import lombok.ToString;

/**
 * @author Ankit Khatri
 */

@Getter
@ToString
public enum ExceptionCode {

    VALIDATION_FAILURE(1001, "Validation failure"),
    VALIDATION_FAILURE_IN_CONTROLLER(1002, "Required data does not match. Please check docs..!");

    private int code;
    private String errorMessage;
    ExceptionCode(int code, String errorMessage){
        this.code = code;
        this.errorMessage = errorMessage;
    }
}
