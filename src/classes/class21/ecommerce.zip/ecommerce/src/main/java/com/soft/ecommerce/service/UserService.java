package com.soft.ecommerce.service;

import com.soft.ecommerce.dto.UserDto;
import com.soft.ecommerce.dto.UserOrder;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface UserService {
    UserDto registerUser(UserDto userDto);
    List<UserDto> getAllUsers();
    List<UserOrder> getAllOrders(String userId);
}
