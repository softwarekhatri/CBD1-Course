package com.soft.ecommerce.converter;

import com.soft.ecommerce.dto.ProductDto;
import com.soft.ecommerce.entity.Product;

/**
 * @author Ankit Khatri
 */
public class ProductConverter {

    public static Product convertToDocument(ProductDto productDto){
        Product p = Product.builder()
                .name(productDto.getName())
                .color(productDto.getColor())
                .price(productDto.getPrice())
                .build();
        return p;
    }

    public static ProductDto convertToDto(Product product){
        ProductDto p = ProductDto.builder()
                .id(product.getId().toHexString())
                .name(product.getName())
                .color(product.getColor())
                .price(product.getPrice())
                .build();
        return p;
    }

}
