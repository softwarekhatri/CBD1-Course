package com.soft.ecommerce.service;

import com.soft.ecommerce.entity.Order;
import com.soft.ecommerce.repo.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Ankit Khatri
 */

@Service
public class OrderServiceImpl implements OrderService{
    @Autowired private OrderRepository orderRepository;

    @Override
    public Order placeOrder(Order order) {
        return orderRepository.save(order);
    }
}
