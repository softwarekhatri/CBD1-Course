package com.soft.ecommerce.repo;

import com.soft.ecommerce.entity.Product;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author Ankit Khatri
 */
public interface ProductRepository extends MongoRepository<Product, ObjectId> {
}
