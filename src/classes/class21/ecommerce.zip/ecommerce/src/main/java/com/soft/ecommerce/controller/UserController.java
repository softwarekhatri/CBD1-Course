package com.soft.ecommerce.controller;

import com.soft.ecommerce.constant.ExceptionCode;
import com.soft.ecommerce.dto.UserDto;
import com.soft.ecommerce.exception.InputValidationException;
import com.soft.ecommerce.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserDto userDto, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            throw new InputValidationException(ExceptionCode.VALIDATION_FAILURE_IN_CONTROLLER);
//            throw new RuntimeException(bindingResult.getFieldError().getDefaultMessage());
        }
        UserDto response = userService.registerUser(userDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/get-all")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/get-all-orders/{userId}")
    public ResponseEntity<?> getAllOrders(@PathVariable String userId){
        return ResponseEntity.ok(userService.getAllOrders(userId));
    }

}
