package com.soft.ecommerce.repo;

import com.soft.ecommerce.entity.User;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author Ankit Khatri
 */
public interface UserRepository extends MongoRepository<User, ObjectId> {
}
