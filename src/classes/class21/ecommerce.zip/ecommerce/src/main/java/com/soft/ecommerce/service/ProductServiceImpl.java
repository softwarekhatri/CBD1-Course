package com.soft.ecommerce.service;

import com.soft.ecommerce.converter.ProductConverter;
import com.soft.ecommerce.dto.ProductDto;
import com.soft.ecommerce.entity.Product;
import com.soft.ecommerce.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired private ProductRepository productRepository;

    @Override
    public ProductDto createNewProduct(ProductDto productDto) {
//        validateInput(productDto);
        Product product = productRepository.save(ProductConverter.convertToDocument(productDto));
        return ProductConverter.convertToDto(product);
    }

    private void validateInput(ProductDto productDto) {
        if(productDto.getColor() == null){
            throw new RuntimeException("Color is required");
        }

    }

    @Override
    public List<ProductDto> getAllProducts() {
        return productRepository.findAll().stream().map(product -> ProductConverter.convertToDto(product)).collect(Collectors.toList());
    }
}
