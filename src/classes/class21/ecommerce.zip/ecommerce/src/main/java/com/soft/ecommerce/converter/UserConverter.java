package com.soft.ecommerce.converter;

import com.soft.ecommerce.dto.UserDto;
import com.soft.ecommerce.entity.User;

/**
 * @author Ankit Khatri
 */

public class UserConverter {

    public static User convertToDocument(UserDto userDto){
        return new User(userDto);
//        User.UserBuilder userBuilder = User.builder();
//        userBuilder = userBuilder.name(userDto.getName());
//        userBuilder = userBuilder.email(userDto.getEmail());
//        userBuilder = userBuilder.password(userDto.getPassword());
//        return userBuilder.build();
//        User user = User.builder()
//                .name(userDto.getName())
//                .email(userDto.getEmail())
//                .password(userDto.getPassword())
//                .build();
//        return user;
    }

    public static UserDto covertToDto(User user){
        UserDto userDto = UserDto.builder()
                .id(user.getId().toHexString())
                .name(user.getName())
                .email(user.getEmail())
                .password(user.getPassword())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getLastUpdatedAt())
                .build();
        return userDto;
    }
}
