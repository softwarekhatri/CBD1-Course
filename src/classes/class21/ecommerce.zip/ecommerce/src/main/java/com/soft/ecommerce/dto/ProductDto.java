package com.soft.ecommerce.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ankit Khatri
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDto {
    private String id;
    @NotEmpty(message = "Product Name can't be empty")
    private String name;
    @NotEmpty(message = "Product Price can't be empty")
    private String price;
    @NotEmpty(message = "Product Color can't be empty")
    private String color;
}
