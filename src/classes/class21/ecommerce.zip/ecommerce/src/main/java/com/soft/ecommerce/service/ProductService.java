package com.soft.ecommerce.service;

import com.soft.ecommerce.dto.ProductDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface ProductService {
    ProductDto createNewProduct(ProductDto productDto);
    List<ProductDto> getAllProducts();
}
