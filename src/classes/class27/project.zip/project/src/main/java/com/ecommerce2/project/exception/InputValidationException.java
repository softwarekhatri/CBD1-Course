package com.ecommerce2.project.exception;

import com.ecommerce2.project.constants.ErrorCode;
import com.ecommerce2.project.dto.ExceptionDto;
import lombok.Data;
import org.springframework.http.HttpStatus;

/**
 * @author Ankit Khatri
 */
@Data
public class InputValidationException extends RuntimeException{

    private HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
    private ExceptionDto exceptionDto;

    public InputValidationException(ErrorCode errorCode){
        this.exceptionDto = new ExceptionDto(errorCode.getCode(), errorCode.getMessage());
    }

    public InputValidationException(ErrorCode errorCode, String details){
        this.exceptionDto = new ExceptionDto(errorCode.getCode(), errorCode.getMessage(), details);
    }
}
