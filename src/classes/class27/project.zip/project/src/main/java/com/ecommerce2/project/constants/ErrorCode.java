package com.ecommerce2.project.constants;

import lombok.Getter;

/**
 * @author Ankit Khatri
 */
@Getter
public enum ErrorCode {

    VALIDATION_FAILURE(1001, "Validation failure"),
    USER_NOT_FOUND(1002, "User not found"),
    INVALID_CREDENTIAL(1003, "Invalid credential"),
    INVALID_TOKEN(1004, "Token is invalid");

    private int code;
    private String message;
    ErrorCode(int code, String message){
        this.code = code;
        this.message = message;
    }
}
