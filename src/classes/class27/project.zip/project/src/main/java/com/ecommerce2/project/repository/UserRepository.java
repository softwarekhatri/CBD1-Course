package com.ecommerce2.project.repository;

import com.ecommerce2.project.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Ankit Khatri
 */
public interface UserRepository extends JpaRepository<User, Integer> {
    User findByEmail(String email);
}
