package com.ecommerce2.project.converter;

import com.ecommerce2.project.dto.UserDto;
import com.ecommerce2.project.entity.User;

/**
 * @author Ankit Khatri
 */
public class UserConverter {

    public static UserDto entityToDto(User user){
        return UserDto.builder()
                .id(user.getId()).name(user.getName()).email(user.getEmail()).password(user.getPassword()).age(user.getAge()).build();
    }

    public static User dtoToEntity(UserDto userDto){
        return User.builder()
                .id(userDto.getId()).name(userDto.getName()).email(userDto.getEmail()).password(userDto.getPassword()).age(userDto.getAge()).build();
    }
}
