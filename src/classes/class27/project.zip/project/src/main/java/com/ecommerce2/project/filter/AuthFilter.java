package com.ecommerce2.project.filter;

import com.ecommerce2.project.service.AuthUserDetailService;
import com.ecommerce2.project.service.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Ankit Khatri
 */

@Component
public class AuthFilter extends OncePerRequestFilter {

    @Autowired private AuthUserDetailService userDetailService;
    @Autowired private JwtService jwtService;

    // 1. check for Authorization token in header
    //  -> If present
//                --> 1. extract the email from the token
//                --> 2. load the username
//                --> 3. verify the token
//                --> 4. set authentication if token is valid
    //  -> If not present
//             --> nothing chain.doFilter(req, res);
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String bearerToken = request.getHeader(HttpHeaders.AUTHORIZATION);
        if(bearerToken != null && bearerToken.startsWith("Bearer ")){
            // "Bearer 39798383ioh3jkjhiry798y398gh39"
            String token = bearerToken.substring(7);
            System.out.println("Jwt Token = " + token);
            String email = this.jwtService.getSubject(token);
            UserDetails userDetails = this.userDetailService.loadUserByUsername(email);
            boolean isValidToken = jwtService.validateToken(token, userDetails.getUsername());
            if(isValidToken && SecurityContextHolder.getContext().getAuthentication() == null){
                UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, new ArrayList<>());
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            }
        }
        filterChain.doFilter(request, response);
    }
}
