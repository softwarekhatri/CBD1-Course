package com.ecommerce2.project.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author Ankit Khatri
 */

@Data
public class LoginRequestDto {

    @NotEmpty(message = "Email must not be empty")
    @Email(message = "Invalid email format")
    private String email;
    @NotEmpty(message = "Password must not be empty")
    private String password;
}
