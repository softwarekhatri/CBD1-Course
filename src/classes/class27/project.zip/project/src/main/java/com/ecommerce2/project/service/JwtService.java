package com.ecommerce2.project.service;

import com.ecommerce2.project.constants.ErrorCode;
import com.ecommerce2.project.exception.InputValidationException;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * @author Ankit Khatri
 */

@Service
@Slf4j
public class JwtService {

    @Value("${application.security.jwt.secret-key}") private String JWT_SECRET_KEY;
    @Value("${application.security.jwt.expiration}") private long JWT_EXPIRATION;

    public String generateToken(final String subject) {
        Assert.notNull(subject, "subject can't be null for generating token..!");
        return this.createToken(new HashMap<>(), subject, this.JWT_EXPIRATION);
    }

    public boolean validateToken(final String token, final String subject) {
        Assert.notNull(token, "Requested token can't be empty for validation..!");
        Assert.notNull(subject, "Subject can't be null for validating token..!");
        final String username = this.getSubject(token);
        final boolean expired = this.isExpired(token);
        final boolean isValidToken = !expired && StringUtils.isNotBlank(username) && username.equals(subject);
        return isValidToken;
    }


    public String getSubject(final String token) {
        Assert.notNull(token, "Token can't ne empty for retrieving username..!");
        return this.getTokenClaim(token, Claims::getSubject);
    }


    public String getSubjectEvenTokenExpired(final String token) {
        Assert.notNull(token, "Token can't ne empty for retrieving subject..!");
        return this.getSubjectEvenWhenTokenIsExpired(token);
    }


    private Date getJwtExpirationDate(String token) {
        return this.getTokenClaim(token, Claims::getExpiration);
    }


    private <T> T getTokenClaim(String token, Function<Claims, T> claimResolver) {
        return claimResolver.apply(this.getAllClaimsFromToken(token));
    }


    private String createToken(Map<String, Object> claims, String subject, long expirationTime) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS256, this.JWT_SECRET_KEY)
                .compact();
    }


    private Claims getAllClaimsFromToken(String token) {
        Jws<Claims> claims = null;
        try {
            claims = Jwts.parser().setSigningKey(this.JWT_SECRET_KEY).parseClaimsJws(token);
        } catch(Exception ex){
            log.info("[JwtAuthenticationService] Invalid token is passed:{}, ex:{}", token, ex.getStackTrace());
            throw new InputValidationException(ErrorCode.INVALID_TOKEN);
        }
        return claims.getBody();
    }


    private String getSubjectEvenWhenTokenIsExpired(String token) {
        Jws<Claims> claims = null;
        try {
            claims = Jwts.parser().setSigningKey(this.JWT_SECRET_KEY).parseClaimsJws(token);
        } catch(ExpiredJwtException ex){
            return ex.getClaims().getSubject();
        } catch (Exception ex){
            log.info("[JwtAuthenticationService] Invalid token received:{}, ex:{}", token, ex.getStackTrace());
            throw new InputValidationException(ErrorCode.INVALID_TOKEN);
        }
        return claims.getBody().getSubject();
    }


    private boolean isExpired(String token) {
        return this.getJwtExpirationDate(token).before(new Date());
    }

}
