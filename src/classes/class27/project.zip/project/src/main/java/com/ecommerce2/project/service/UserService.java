package com.ecommerce2.project.service;

import com.ecommerce2.project.dto.LoginRequestDto;
import com.ecommerce2.project.dto.LoginResponseDto;
import com.ecommerce2.project.dto.UserDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface UserService {

    UserDto registerNewUser(UserDto userDto);
    List<UserDto> getAllUsers();
    LoginResponseDto loginUser(LoginRequestDto loginRequestDto);
}
