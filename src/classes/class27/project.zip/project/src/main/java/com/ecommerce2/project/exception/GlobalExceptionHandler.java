package com.ecommerce2.project.exception;

import com.ecommerce2.project.constants.ErrorCode;
import com.ecommerce2.project.dto.ExceptionDto;
import io.jsonwebtoken.security.SignatureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


/**
 * @author Ankit Khatri
 */

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InputValidationException.class)
    public ResponseEntity<?> handleInputValidationException(InputValidationException ex){
        return ResponseEntity.status(ex.getHttpStatus()).body(ex.getExceptionDto());
    }

    @ExceptionHandler(SignatureException.class)
    public ResponseEntity<?> handleSignatureException(SignatureException ex){
        ExceptionDto exceptionDto = new ExceptionDto(ErrorCode.INVALID_TOKEN.getCode(), ErrorCode.INVALID_TOKEN.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(exceptionDto);
    }

    @ExceptionHandler({BadCredentialsException.class, UsernameNotFoundException.class})
    public ResponseEntity<?> handleBadCredentials(Exception ex){
        ExceptionDto exceptionDto = new ExceptionDto(ErrorCode.INVALID_CREDENTIAL.getCode(), ErrorCode.INVALID_CREDENTIAL.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(exceptionDto);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleAnyException(Exception ex){
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getStackTrace());
    }
}
