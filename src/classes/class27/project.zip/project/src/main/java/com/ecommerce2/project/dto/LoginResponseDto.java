package com.ecommerce2.project.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ankit Khatri
 */

@Data
@NoArgsConstructor
public class LoginResponseDto {

    private String token;
    private String tokenType;

    public LoginResponseDto(String token, String tokenType){
        this.token = token;
        this.tokenType = tokenType;
    }
}
