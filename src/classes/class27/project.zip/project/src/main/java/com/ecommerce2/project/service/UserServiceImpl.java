package com.ecommerce2.project.service;

import com.ecommerce2.project.converter.UserConverter;
import com.ecommerce2.project.dto.LoginRequestDto;
import com.ecommerce2.project.dto.LoginResponseDto;
import com.ecommerce2.project.dto.UserDto;
import com.ecommerce2.project.entity.User;
import com.ecommerce2.project.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
@Slf4j
public class UserServiceImpl implements UserService{

    @Autowired private UserRepository userRepository;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private JwtService jwtService;
    @Autowired private PasswordEncoder passwordEncoder;

    @Override
    public UserDto registerNewUser(UserDto userDto) {
        User user = UserConverter.dtoToEntity(userDto);
        user.setPassword(this.passwordEncoder.encode(userDto.getPassword()));
        User savedUser = userRepository.saveAndFlush(user);
        log.info("User registered successfully");
        return UserConverter.entityToDto(savedUser);
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream().map(user -> UserConverter.entityToDto(user)).collect(Collectors.toList());
    }

    // 1. if authentication succeeds -> it will not throw any error
    // 2. If authentication fails -> BadCredentialsException

    // 1. can validate the email & password -> authenticationManager
    // 2. We need to generate Jwt token
    // 3. return the token (LoginResponseDto)
    @Override
    public LoginResponseDto loginUser(LoginRequestDto loginRequestDto) {
        UsernamePasswordAuthenticationToken authenticationObject = new UsernamePasswordAuthenticationToken(loginRequestDto.getEmail(), loginRequestDto.getPassword());
        authenticationManager.authenticate(authenticationObject);
        String jwtToken = jwtService.generateToken(loginRequestDto.getEmail());
        LoginResponseDto responseDto = new LoginResponseDto(jwtToken, "Bearer");
        return responseDto;
    }
}
