package com.ecommerce2.project.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ankit Khatri
 */

@Data
@NoArgsConstructor
public class ExceptionDto {

    private int code;
    private String message;
    private String details;

    public ExceptionDto(int code, String message){
        this.code = code;
        this.message = message;
    }

    public ExceptionDto(int code, String message, String details){
        this.code = code;
        this.message = message;
        this.details = details;
    }
}
