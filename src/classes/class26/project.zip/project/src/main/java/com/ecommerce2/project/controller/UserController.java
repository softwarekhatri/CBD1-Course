package com.ecommerce2.project.controller;

import com.ecommerce2.project.constants.ErrorCode;
import com.ecommerce2.project.dto.UserDto;
import com.ecommerce2.project.exception.InputValidationException;
import com.ecommerce2.project.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

    @Autowired private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerNewUser(@Valid @RequestBody UserDto userDto, BindingResult bindingResult){
        log.info("Request recieved for registering new user:{}", userDto);
        if(bindingResult.hasErrors()){
            String errorMessage = bindingResult.getFieldErrors().stream().map(s -> s.getDefaultMessage()).collect(Collectors.joining(","));
            log.error("Validation failure happens due to :{}", errorMessage);
            throw new InputValidationException(ErrorCode.VALIDATION_FAILURE, errorMessage);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(this.userService.registerNewUser(userDto));
    }

    @GetMapping("/get-users")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.status(HttpStatus.OK).body(this.userService.getAllUsers());
    }
}
