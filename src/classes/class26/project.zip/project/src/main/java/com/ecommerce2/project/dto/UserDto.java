package com.ecommerce2.project.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ankit Khatri
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Integer id;
    @NotEmpty(message = "Name can not be empty")
    private String name;
    @NotEmpty(message = "Email can not be empty")
    @Email(message = "Email format is invalid")
    private String email;
    @NotEmpty(message = "Password is required")
    private String password;
    private Integer age;
}
