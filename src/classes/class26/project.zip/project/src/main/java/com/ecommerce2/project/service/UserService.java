package com.ecommerce2.project.service;

import com.ecommerce2.project.dto.UserDto;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface UserService {

    UserDto registerNewUser(UserDto userDto);
    List<UserDto> getAllUsers();
}
