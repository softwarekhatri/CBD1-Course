package com.ecommerce2.project.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author Ankit Khatri
 */

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InputValidationException.class)
    public ResponseEntity<?> handleInputValidationException(InputValidationException ex){
        return ResponseEntity.status(ex.getHttpStatus()).body(ex.getExceptionDto());
    }
}
