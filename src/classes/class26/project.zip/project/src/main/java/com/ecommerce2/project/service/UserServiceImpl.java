package com.ecommerce2.project.service;

import com.ecommerce2.project.converter.UserConverter;
import com.ecommerce2.project.dto.UserDto;
import com.ecommerce2.project.entity.User;
import com.ecommerce2.project.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Ankit Khatri
 */

@Service
@Slf4j
public class UserServiceImpl implements UserService{

    @Autowired private UserRepository userRepository;

    @Override
    public UserDto registerNewUser(UserDto userDto) {
        User savedUser = userRepository.saveAndFlush(UserConverter.dtoToEntity(userDto));
        log.info("User registered successfully");
        return UserConverter.entityToDto(savedUser);
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream().map(user -> UserConverter.entityToDto(user)).collect(Collectors.toList());
    }
}
