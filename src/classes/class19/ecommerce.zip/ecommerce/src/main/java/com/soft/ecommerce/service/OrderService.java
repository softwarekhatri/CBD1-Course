package com.soft.ecommerce.service;

import com.soft.ecommerce.entity.Order;

/**
 * @author Ankit Khatri
 */
public interface OrderService {

    Order placeOrder(Order order);
}
