package com.soft.ecommerce.repo;

import com.soft.ecommerce.entity.Order;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;




/**
 * @author Ankit Khatri
 */
public interface OrderRepository extends MongoRepository<Order, ObjectId> {

    List<Order> findByUserId(String userId);
}
