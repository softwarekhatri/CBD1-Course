package com.soft.ecommerce.controller;

import com.soft.ecommerce.entity.Order;
import com.soft.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired private OrderService orderService;

    @PostMapping("/place-order")
    public ResponseEntity<?> placeOrder(@RequestBody Order order){
        return ResponseEntity.ok(orderService.placeOrder(order));
    }
}
