package com.soft.ecommerce.dto;

import com.soft.ecommerce.entity.Product;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Ankit Khatri
 */

@Data
public class UserOrder {

    private String userId;
    private List<Product> products;
    private String paymentId;
    private String orderId;
    private Date orderPlacedAt;
}
