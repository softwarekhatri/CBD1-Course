package com.school.student.service;

import com.school.student.entity.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Ankit Khatri
 */

@Service
public class StudentServiceImpl implements StudentService{

    static List<Student> studentList = new ArrayList<>();

    @Override
    public void createNewStudent(Student student){
        studentList.add(student);
        System.out.println(studentList);
}

    @Override
    public List<Student> getAllStudents() {
        return studentList;
    }

    @Override
    public Student getStudentById(String studentId) {
//        Optional<Student> optional = studentList.stream().filter(s -> s.getId().equals(studentId)).findAny().get() == null ? n;
        for(Student s: studentList){
            if(s.getId().equals(studentId)){
                return s;
            }
        }
        return null;
    }

    @Override
    public void updateStudent(String studentId, Student inputData) {
        for(int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).getId().equals(studentId)) {
                studentList.set(i, inputData);
            }
        }
    }

    @Override
    public void deleteStudent(String studentId) {
        for(int i = 0; i < studentList.size(); i++){
            if(studentList.get(i).getId().equals(studentId)){
                studentList.remove(i);
                return;
            }
        }
    }


}
