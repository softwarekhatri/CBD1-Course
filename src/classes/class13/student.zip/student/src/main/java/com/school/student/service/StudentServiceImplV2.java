//package com.school.student.service;
//
//import com.school.student.entity.Student;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
///**
// * @author Ankit Khatri
// */
//
//public class StudentServiceImplV2 implements StudentService{
//    @Override
//    public void createNewStudent(Student student) {
//
//    }
//
//    @Override
//    public List<Student> getAllStudents() {
//        return null;
//    }
//}
