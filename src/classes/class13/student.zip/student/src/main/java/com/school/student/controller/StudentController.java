package com.school.student.controller;

import com.school.student.entity.Student;
import com.school.student.service.StudentService;
import com.school.student.service.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    StudentService studentService;

    // localhost:8080/student/create
    @PostMapping("/create")
    public String createStudent(@RequestBody Student inputData){
        System.out.println("inputData " + inputData);
        studentService.createNewStudent(inputData);
        return "created";
    }

    @GetMapping("/")
    public List<Student> getStudents(){
        return studentService.getAllStudents();
    }

    @GetMapping("/get/{id}")
    public Student getStudentById(@PathVariable("id") String studentId){
        return studentService.getStudentById(studentId);
    }

    @PutMapping("/update/{studentId}")
    public String updateStudent(@PathVariable String studentId, @RequestBody Student inputUpdatedData){
        studentService.updateStudent(studentId, inputUpdatedData);
        return "updated";
    }

    @DeleteMapping("/delete/{studentId}")
    public String deleteStudent(@PathVariable String studentId){
        studentService.deleteStudent(studentId);
        return "deleted";
    }

}
