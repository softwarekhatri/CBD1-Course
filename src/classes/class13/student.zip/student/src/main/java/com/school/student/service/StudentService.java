package com.school.student.service;

import com.school.student.entity.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface StudentService {

    public void createNewStudent(Student student);

    public List<Student> getAllStudents();

    Student getStudentById(String studentId);

    void updateStudent(String studentId, Student inputData);

    void deleteStudent(String studentId);
}
