package com.company.employee.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * @author Ankit Khatri
 */
@Data
@Entity
@Table(name = "employee_details")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "first_name")
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String department;
//
//    @OneToOne
//    private Address address;
}
