package com.company.employee.service;

import com.company.employee.entity.Employee;
import com.company.employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Ankit Khatri
 */

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired private EmployeeRepository employeeRepository;

    @Override
    public String createNewEmployee(Employee employee) {
        employeeRepository.saveAndFlush(employee);
        return "created";
    }

    @Override
    public Employee getEmployeeById(Integer id) {
        Optional<Employee> employeeOptional = employeeRepository.findById(id);
        if(employeeOptional.isPresent()){
            return employeeOptional.get();
        }
        return null;
    }

    @Override
    public List<Employee> getEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public String updateEmployee(Integer id, Employee employee) {
        employee.setId(id);
        employeeRepository.saveAndFlush(employee);
        return "No employee found";
    }

    @Override
    public String deleteEmployee(Integer id) {
        employeeRepository.deleteById(id);
        return "No employee found";
    }
}
