package com.company.employee.repository;

import com.company.employee.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
