package com.company.employee.controller;

import com.company.employee.entity.Employee;
import com.company.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Ankit Khatri
 */

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired private EmployeeService employeeService;

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseEntity<String> createEmployee(@RequestBody Employee inputData){
        String message = employeeService.createNewEmployee(inputData);
        return ResponseEntity.status(HttpStatus.CREATED).body(message);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Employee>> getEmployees(){
        List<Employee> employeeList = employeeService.getEmployees();
        return ResponseEntity.status(HttpStatus.OK).body(employeeList);
    }

    @RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Integer id){
        Employee employee = employeeService.getEmployeeById(id);
        return ResponseEntity.status(HttpStatus.OK).body(employee);
    }

//    @RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateEmployee(@PathVariable Integer id, @RequestBody Employee inputData){
        String updatedMessage = employeeService.updateEmployee(id, inputData);
        return ResponseEntity.status(HttpStatus.OK).body(updatedMessage);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable Integer id){
        employeeService.deleteEmployee(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

}
