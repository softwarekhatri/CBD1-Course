package com.company.employee.service;

import com.company.employee.entity.Employee;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface EmployeeService {
    String createNewEmployee(Employee employee);
    Employee getEmployeeById(Integer id);
    List<Employee> getEmployees();
    String updateEmployee(Integer id, Employee employee);
    String deleteEmployee(Integer id);
}
