package com.soft.user.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * @author Ankit Khatri
 */
// POJO ==> Plain old java object

@Service
public class AuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        if(request.getHeader("Authorization") != null && request.getHeader("Authorization").startsWith("Token:")){
            // secured apis
            // validate token
            // set authentication
        }
        chain.doFilter(request, response);
    }

}
