package com.soft.user.constants;

import lombok.Getter;

/**
 * @author Ankit Khatri
 */
@Getter
public enum ExceptionCode {

    USERNAME_PASSWORD_REQUIRES(1000, "username & password is required for login"),
    INVALID_CREDENTIALS(1001, "Invalid credentials"),
    PASSWORD_NOT_MATCHES(1002, "password does not match");

    private int code;
    private String message;

    ExceptionCode(int code, String message){
        this.code = code;
        this.message = message;
    }
}
