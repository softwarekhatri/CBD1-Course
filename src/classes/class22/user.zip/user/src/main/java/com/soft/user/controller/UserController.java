package com.soft.user.controller;

import com.soft.user.dto.UserDto;
import com.soft.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author Ankit Khatri
 */
@RestController
@RequestMapping("/my-user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/my-register")
    public ResponseEntity<?> registerUser(@RequestBody UserDto userDto){
        UserDto response = userService.registerUser(userDto);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/get-all")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/get-by-id/{userId}")
    public ResponseEntity<?> getUser(@PathVariable("userId") Integer userId){
        return ResponseEntity.ok(userService.getUserById(userId));
    }

//    @GetMapping("/get-all-orders/{userId}")
//    public ResponseEntity<?> getAllOrders(@PathVariable String userId){
//        return ResponseEntity.ok(userService.getAllOrders(userId));
//    }

}