package com.school.student.service;

import com.school.student.entity.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ankit Khatri
 */

@Service
public class StudentServiceImpl implements StudentService{

    static List<Student> studentList = new ArrayList<>();

    @Override
    public void createNewStudent(Student student){
        studentList.add(student);
        System.out.println(studentList);
}

    @Override
    public List<Student> getAllStudents() {
        return studentList;
    }


}
