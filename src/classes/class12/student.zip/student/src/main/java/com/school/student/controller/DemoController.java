package com.school.student.controller;

import com.school.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ankit Khatri
 */

@RestController
public class DemoController {

    // localhost:8080/
    @PostMapping("/hello")
    public String returnMessage(){
        return "Hello world";
    }

    @GetMapping("/")
    public String defaultView(){
        return "<h1>Default</h1>";
    }
}
