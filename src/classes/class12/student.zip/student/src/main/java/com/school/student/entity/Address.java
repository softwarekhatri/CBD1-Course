package com.school.student.entity;

/**
 * @author Ankit Khatri
 */
public class Address {

    private String address1;
    private String state;
    private Integer zip;

    @Override
    public String toString() {
        return "Address{" +
                "address1='" + address1 + '\'' +
                ", state='" + state + '\'' +
                ", zip=" + zip +
                '}';
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getZip() {
        return zip;
    }

    public void setZip(Integer zip) {
        this.zip = zip;
    }
}
