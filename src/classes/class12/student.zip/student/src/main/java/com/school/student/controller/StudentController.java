package com.school.student.controller;

import com.school.student.entity.Student;
import com.school.student.service.StudentService;
import com.school.student.service.StudentServiceImpl;
import com.school.student.service.StudentServiceImplV2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Ankit Khatri
 */

@RestController
public class StudentController {

    @Autowired
    StudentService studentService;

    @PostMapping("/create")
    public String createStudent(@RequestBody Student inputData){
        System.out.println("inputData " + inputData);
        studentService.createNewStudent(inputData);
        return "created";
    }

    @GetMapping("/all")
    public List<Student> getStudents(){
        return studentService.getAllStudents();
    }

    @GetMapping("/get/")
    public String getStudentById(){
        return null;
    }

    @PutMapping("/update")
    public String updateStudent(){
        return null;
    }

    @DeleteMapping("/delete")
    public String deleteStudent(){
        return null;
    }

}
