package com.eCommerce.product.dto;

import com.eCommerce.product.constant.ProductCategory;
import lombok.Data;

import java.util.List;

/**
 * @author Ankit Khatri
 */

@Data
public class ProductDto {

    private String id;
    private String name;
    private List<String> images;
    private String category;
    private Double ratings;
    private Double price;
    private Integer stockQuantity;

}
