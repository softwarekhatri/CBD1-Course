package com.eCommerce.product.dao;

import com.eCommerce.product.entity.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * @author Ankit Khatri
 */
public interface ProductRepository extends MongoRepository<Product, Integer> {

    // HQL -> Hibernate Query Language
//    @Query("SELECT p from Product p where p.name = ?1")
//    List<Product> findByEmail(String name);

//    @Query("SELECT p from Product p where p.name LIKE %?1% OR p.category LIKE %?1%")
    List<Product> findByNameContainingOrCategoryContaining(String name, String category);

//    @Query("SELECT p FROM Product p where p.name = ?1 ORDER BY DESC")
//    List<Product> findByOrderByNameDesc(String name);

}
